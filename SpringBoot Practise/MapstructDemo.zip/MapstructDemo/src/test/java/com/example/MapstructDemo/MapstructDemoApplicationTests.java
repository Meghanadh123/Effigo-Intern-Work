package com.example.MapstructDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapstructDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
